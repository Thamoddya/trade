
<link rel="stylesheet" href="./assets/css/bootstrap-icons.css">
<link rel="stylesheet" href="./assets/css/bootstrap.css">
<link rel="stylesheet" href="./assets/css/style.css">
<script src="./assets/js/kit.fontawesome.com_3840ac106f.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>