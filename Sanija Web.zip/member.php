<?php
session_start();
$userData = json_decode($_SESSION['userData']);
include_once './connection.php';


$getUserData = $pdo->prepare("SELECT * FROM member WHERE nic=:nic");
$getUserData->bindValue(':nic', $userData[0]->nic);
$getUserData->execute();
$liveUserData = $getUserData->fetch(PDO::FETCH_ASSOC);
if($liveUserData['status']==0){
    echo "Hello ".$liveUserData['name'].".Your Account has been not activated yet.Please Come back Later.";
    exit();
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TRADEWAVE Member | HOME</title>
    <?php
    include_once './components/header.php';
    ?>
</head>
<body class="container-fluid">
<nav class="navbar bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand"><?php echo $liveUserData['name'] ?></a>
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
    </div>
</nav>
<hr>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-12 col-md-4 border-white border border-2 bg-dark  justify-content-center align-items-center text-white text-center">
            <br>
            <p>Account Balance : <?php echo $liveUserData['balance'] ?> $</p>
            <br>
        </div>
        <div class="col-12 col-md-4 border-white border border-2 bg-dark  justify-content-center align-items-center text-white text-center">
            <br>
            <p>Referral Balance : coming soon </p>
            <br>
        </div>
        <div class="col-12 col-md-4 border-white border border-2 bg-dark  justify-content-center align-items-center text-white text-center">
            <br>
            <p>Ongoing Balance : <?php echo $liveUserData['balance'] ?> $</p>
            <br>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-12 col-md-6 border border-2 border-white rounded-2 bg-dark text-white">
            <div class="row">
                <div class="col-12 mt-2">
                    <h4>User Data</h4>
                    <hr>
                </div>
                <div class="col-12 mt-1">
                    <p>Wallet ID : <?php echo $userData['0']->walletID ?> </p>
                    <!--                    <input type="text" class="input-group rounded bg-transparent border-dark text-white" value="-->
                    <?php //echo $userData['0']->walletID ?><!--" readonly>-->
                </div>
                <div class="col-12">
                    <p>Referral ID : <?php echo $userData['0']->referral ?> </p>
                </div>
                <div class="col-12">
                    <p>Verified Status :
                        <?php
                        if ($liveUserData['emailVerifyed'] == '0') {
                            echo "<span class='text-danger'>Email Not Verified <a href='#accountVerify'  data-bs-toggle='offcanvas'  >Click Here To Verify</a> </span>";
                        } else {
                            echo "<span class='text-success'>Verified</span>";
                        }
                        ?>
                    </p>
                </div>
                <div class="col-12 mb-2">
                    <div class="row">
                        <div class="col-6">
                            <button type="button" class="button-9" onclick="goToDiscord();">Recharge Account</button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="button-9">Withdraw Money</button>
                        </div>
                        <div class="col-12 mt-1">
                            <button type="button" class="button-9">Send Money</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-6 border border-2 border-white rounded-2 bg-dark text-white">
            <div class="row mt-3 border-dark border border-2">
                <table class=" col-12 table table-bordered border-primary">
                    <tbody>
                    <tr class="text-center">
                        <td>BTC : <span id="btcPrice"></span></td>
                        <td>SOL : <span id="solPrice"></span></td>
                    </tr>
                    <tr class="text-center">
                        <td>DOGE : <span id="dogePrice"></span></td>
                        <td>TRX : <span id="trxPrice"></span></td>
                    </tr>
                    </tbody>
                </table>
                <div class="col-12 mt-3">
                    <img src="./assets/img/tradewave%20banner.svg" style="width: 100%;border: none">
                </div>
            </div>
        </div>
    </div>
</div>
<p class="text-danger">*Please Note that , this website is still developing and This is the beta version</p>
<div class="offcanvas offcanvas-start" tabindex="-1" id="accountVerify" aria-labelledby="accountVerify">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasExampleLabel">TRADEWAVE | Verify Email</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <hr>
        <div>
            Your Email is not verified.Click the given button to get verification code to your email and enter the code
            and Verify Your account for future transactions.
        </div>

        <div class="col-12">
            <button class="button-9" id="sendEmailButton"
                    onclick="sendEmailCode(<?php echo $liveUserData['verification-code'] ?>);">Get Code To Email
            </button>
        </div>
        <div class="col-12 mt-3">
            <input type="text" class="input-group border border-dark" id="inputVerifyCode"
                   placeholder="Enter Your Code Here">
            <button type="button" class="buttonDownload mt-2" onclick="verifyAccount();">Verify Account</button>
        </div>
    </div>
</div>

<?php
include_once './components/footer.php';
?>


<script>
    const sendEmailCode = (verifyID) => {
        $('#sendEmailButton').prop('disabled', true);
        $('#sendEmailButton').html('Wait...');

        let form = new FormData();
        form.append("verifyID", verifyID);

        $.ajax({
            type: 'POST',
            url: './process/sendCode.process.php',
            data: form,
            contentType: false,
            processData: false,
            success: (response) => {
                let data = JSON.parse(response);
                if (data.error == 'false') {
                    swal.fire("Done");
                } else {
                    console.log(data.errormsg)
                }
                ;
            }
        });
    };

    const verifyAccount = () => {
        let enteredCode = $("#inputVerifyCode").val();
        let form = new FormData();
        form.append("code", enteredCode);
        form.append("Realcode", '<?php echo $liveUserData["verification-code"] ?>');

        $.ajax({
            type: 'POST',
            url: './process/verifyAccount.process.php',
            data: form,
            contentType: false,
            processData: false,
            success: (response) => {
                console.log(response)
                let data = JSON.parse(response);
                if (data.error == 'false') {
                    swal.fire("Done");
                    window.location.reload();
                } else {
                    swal.fire(data.errorMsg)
                }
                ;
            }
        });
    };

    const goToDiscord = () => {
            Swal.fire({
                title: '<strong>Recharge Account</strong>',
                icon: 'info',
                html:
                    'Click Here To <b>Recharge Account</b>, ' +
                    '<a href="https://discord.gg/9VRQjYW2">Click Here</a> ' +
                    'Contact To Recharge ',
                showCloseButton: true,
                showCancelButton: true,
                focusConfirm: false,


            });
        };
</script>
</body>
</html>
