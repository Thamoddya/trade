<?php
session_start();
include_once "./connection.php";
//if($_SESSION['role'] == 'admin'){
//    header('Location : ./index.php');
//}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TradeWave Admin</title>
    <link rel="shortcut icon" href="./assets/img/login.main.svg" type="image/x-icon">
    <?php
    include_once './components/header.php';
    ?>

</head>

<body  style="background-color: #1f1151;width: 100%;height: 100vh">

<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">ADMIN | TRADEWAVE</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="./verify.admin.php">Verification</a>
                </li>
<!--                <li class="nav-item">-->
<!--                    <a class="nav-link" href="#">Link</a>-->
<!--                </li>-->
<!--                <li class="nav-item dropdown">-->
<!--                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
<!--                        Dropdown-->
<!--                    </a>-->
<!--                    <ul class="dropdown-menu">-->
<!--                        <li><a class="dropdown-item" href="#">Action</a></li>-->
<!--                        <li><a class="dropdown-item" href="#">Another action</a></li>-->
<!--                        <li><hr class="dropdown-divider"></li>-->
<!--                        <li><a class="dropdown-item" href="#">Something else here</a></li>-->
<!--                    </ul>-->
<!--                </li>-->
<!--                <li class="nav-item">-->
<!--                    <a class="nav-link disabled" aria-disabled="true">Disabled</a>-->
<!--                </li>-->
            </ul>
            <form class="d-flex" role="search">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
</nav>


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="row mt-5">
                <div class="col-12 col-md-4 offset-0 offset-md-1  d-flex justify-content-center align-items-center text-white h-25 fs-3" style="background-color: darkgrey;">
                    MEMBERS :- 50
                    <br>
                    BALANCE :- 1000$
                </div>
                <div class="col-12 col-md-4 mt-1 mt-md-0 offset-0 offset-md-2  d-flex justify-content-center align-items-center text-white h-25 fs-3" style="background-color: darkgrey;">
                    <div class="row">
                        <div class="col-12 d-flex justify-content-center align-items-center">
                            <p>BTC Price: <span id="btcPrice"></span></p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center">
                            <p>TRX Price: <span id="trxPrice"></span></p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center">
                            <p>DOGE Price: <span id="dogePrice"></span></p>
                        </div>
                        <div class="col-12 d-flex justify-content-center align-items-center">
                            <p>SOL Price: <span id="solPrice"></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
<div class="row">
    <div class="col-12">
        <h2 class="text-white ">Member Details</h2>
    </div>
    <div class="col-12 overflow-auto">
        <table class="table table-dark table-hover">
            <?php
            $memberDataGet = $pdo->prepare('SELECT * FROM member WHERE `status`="1" ');
            $memberDataGet->execute();
            ?>
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Balance</th>
                <th scope="col"></th>
                <th scope="col">Go</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $count = 1;
            while ($memberData = $memberDataGet->fetch(PDO::FETCH_ASSOC)) {
                $memberNic = $memberData['nic'];
                $name = $memberData['name'];
                $email = $memberData['email'];
                $balance = $memberData['balance'];

                echo "<tr>";
                echo "<th scope='row'>$count</th>";
                echo "<td>$name</td>";
                echo "<td>$email</td>";
                echo "<td>$balance USD</td>";
                echo "<td>
                    <input type='number' id='balance_$memberNic' />
                    <button class='buttonDownload' onclick='updateBalance($memberNic)'>UPDATE</button>
                  </td>";
                echo "<td><button class='buttonDownload'>View</button></td>";
                echo "</tr>";

                $count++;
            }
            ?>
            </tbody>
        </table>
    </div>
</div>
</div>


<?php
include_once './components/footer.php';
?>

<script>

    const updateBalance = (nic)=>{
        let balance = $(`#balance_${nic}`).val();

        let form =  new FormData();
        form.append("nic",nic);
        form.append("balance",balance);

        $.ajax({
            type :'POST',
            url:'./process/updateBalance.process.php',
            data:form,
            contentType:false,
            processData: false,
            success:(response)=>{
                let data  = JSON.parse(response);
                if(data.error == 'false'){
                    swal.fire("Done");
                    window.location.reload();
                }else{
                    swal.fire(data.errormsg)
                }
            }
        })
    }



</script>
</body>

</html>